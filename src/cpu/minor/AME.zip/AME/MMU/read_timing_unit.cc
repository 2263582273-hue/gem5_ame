#include "cpu/minor/AME/MMU/read_timing_unit.hh"

#include "params/MemUnitReadTiming.hh"

namespace gem5
{

MemUnitReadTiming::MemUnitReadTiming(const MemUnitReadTimingParams *p)
    : TickedObject(*p),
      channel(p->channel),
      cacheLineSize(p->cacheLineSize),
      VRF_LineSize(p->VRF_LineSize),
      done(true),
      readFunction(nullptr),
      vecIndex(0),
      amewrapper(nullptr)
{
}

MemUnitReadTiming::~MemUnitReadTiming()
{
}

void
MemUnitReadTiming::evaluate()
{
    if (readFunction && readFunction()) {
        done = true;
        stop();
    }
}

void
MemUnitReadTiming::regStats()
{
    TickedObject::regStats();
    Cache_line_r_req
        .name(name() + ".cacheLineReadRequests")
        .desc("Number of AME cache line read requests");
}

void
MemUnitReadTiming::queueData(uint8_t *data)
{
    dataQ.push_back(data);
}

void
MemUnitReadTiming::initialize(AMEInterface& vector_wrapper, uint64_t count,
    uint64_t DST_SIZE, uint64_t mem_addr, uint8_t mop, uint64_t stride,
    Location data_from, ExecContextPtr& xc,
    std::function<void(uint8_t*, uint8_t, bool)> on_item_load)
{
    (void)count;
    (void)DST_SIZE;
    (void)mem_addr;
    (void)mop;
    (void)stride;
    (void)data_from;
    (void)xc;
    (void)on_item_load;

    amewrapper = &vector_wrapper;
    done = false;
    vecIndex = 0;
    readFunction = [this]() { return true; };
    start();
}

MemUnitReadTiming *
MemUnitReadTimingParams::create() const
{
    return new MemUnitReadTiming(this);
}

} // namespace gem5
