#ifndef __CPU_MEM_UNIT_READ_TIMING__
#define __CPU_MEM_UNIT_READ_TIMING__

#include <cstdint>
#include <functional>
#include <queue>

// #include "cpu/minor/AME/ame_interface.hh"
#include "base/statistics.hh"
#include "cpu/exec_context.hh"
#include "cpu/minor/AME/defines.hh"
#include "params/MemUnitReadTiming.hh"
#include "sim/ticked_object.hh"


namespace gem5 {
class AMEInterface;

class MemUnitReadTiming : public TickedObject
{
public:
    MemUnitReadTiming(const MemUnitReadTimingParams *p);
    ~MemUnitReadTiming();

    // overrides
    void evaluate() override;
    void regStats() override;
    // Queuedata is used for indexed operations
    void queueData(uint8_t *data);
    void initialize(AMEInterface& vector_wrapper,uint64_t count,
        uint64_t DST_SIZE,uint64_t mem_addr,uint8_t mop,uint64_t stride,
        Location data_from, ExecContextPtr& xc,
        std::function<void(uint8_t*,uint8_t,bool)> on_item_load);

private:
    //set by params
    const uint8_t channel;
    const uint64_t cacheLineSize;
    const uint64_t VRF_LineSize;

    volatile bool done;
    std::function<bool(void)> readFunction;
    //Used by indexed Operations to hold the element index
    std::deque<uint8_t *> dataQ;
    //modified by readFunction closure over time
    uint64_t vecIndex;
    AMEInterface* amewrapper;
public:
    // Stat for number of cache lines read requested
    statistics::Scalar Cache_line_r_req;

};
}






#endif //__CPU_MEM_UNIT_READ_TIMING__
