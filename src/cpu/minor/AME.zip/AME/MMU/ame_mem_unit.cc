#include "cpu/minor/AME/MMU/ame_mem_unit.hh"

#include "arch/riscv/insts/matrix.hh"
#include "params/AMEMemUnit.hh"

namespace gem5
{

AMEMemUnit::AMEMemUnit(const AMEMemUnitParams *p)
    : SimObject(*p),
      occupied(false),
      memReader(p->memReader),
      memWriter(p->memWriter),
      amewrapper(nullptr)
{
}

AMEMemUnit::~AMEMemUnit()
{
}

bool
AMEMemUnit::isOccupied()
{
    return occupied;
}

void
AMEMemUnit::issue(AMEInterface& vector_wrapper, InstQueue::QueueEntry &inst)
{
    assert(!occupied);
    amewrapper = &vector_wrapper;
    occupied = true;
    auto curinst=dynamic_cast<gem5::RiscvISA::MatrixMicroInst*>(inst.inst->staticInst.get());
    uint8_t ls=curinst->ls;
    uint8_t eew=curinst->eew;
    uint8_t tr=curinst->tr;
    

}

AMEMemUnit *
AMEMemUnitParams::create() const
{
    return new AMEMemUnit(this);
}

} // namespace gem5
