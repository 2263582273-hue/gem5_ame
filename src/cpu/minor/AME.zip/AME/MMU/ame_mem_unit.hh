#ifndef __CPU_MEM_UNIT_HH__
#define __CPU_MEM_UNIT_HH__

#include <functional>
#include "cpu/minor/dyn_inst.hh"
#include "cpu/minor/AME/inst_queue.hh"
#include  "cpu/minor/AME/MMU/read_timing_unit.hh"
#include "cpu/minor/AME/MMU/write_timing_unit.hh"
#include "params/AMEMemUnit.hh"

namespace gem5{

class AMEInterface;

class AMEMemUnit : public SimObject
{
  public:
    AMEMemUnit(const AMEMemUnitParams *p);
    ~AMEMemUnit();

    bool isOccupied();
    void issue(AMEInterface& vector_wrapper,InstQueue::QueueEntry &inst);

  private:
    bool occupied;
    MemUnitReadTiming * memReader;
    MemUnitWriteTiming * memWriter;

    AMEInterface* amewrapper;

    uint64_t vt(uint64_t val, int lo, int len) const {
      return (val >> lo) & ((uint64_t(1) << len)-1);
    }
};
}




#endif // __CPU_MEM_UNIT_HH__
